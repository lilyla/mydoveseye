var populate = require('./populate'),
    update   = require('./update'),
    fixtures = require('./fixtures');

module.exports = {
    populate: populate,
    update: update,
    fixtures: fixtures
};
